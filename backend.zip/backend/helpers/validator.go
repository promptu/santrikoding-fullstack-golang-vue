package helpers

import (
	"fmt"
	"strings"

	"github.com/go-playground/validator/v10"
	"gorm.io/gorm"
)

func TranslateErrorMessage(err error) map[string]string {
	errorsMap := make(map[string]string)

	if validationErrors, ok := err.(validator.ValidationErrors); ok {
		for _, fieldError := range validationErrors {
			field := fieldError.Field()
			switch fieldError.Tag() {
			case "required":
				errorsMap[field] = fmt.Sprintf("%s harus diisi", field)
			case "email":
				errorsMap[field] = "Format email tidak valid"
			case "unique":
				errorsMap[field] = fmt.Sprintf("%s sudah ada", field)
			case "min":
				errorsMap[field] = fmt.Sprintf("%s minimal %s karakter", field, fieldError.Param())
			case "max":
				errorsMap[field] = fmt.Sprintf("%s maksimal %s karakter", field, fieldError.Param())
			case "numeric":
				errorsMap[field] = fmt.Sprintf("%s harus angka", field)
			default:
				errorsMap[field] = "Data tidak valid"
			}
		}
	}

	if err != nil {
		if strings.Contains(err.Error(), "Data duplikat") {
			if strings.Contains(err.Error(), "username") {
				errorsMap["Username"] = "Username sudah terdaftar"
			}
			if strings.Contains(err.Error(), "email") {
				errorsMap["Email"] = "Email sudah terdaftar"
			}
		} else if err == gorm.ErrRecordNotFound {
			errorsMap["Error"] = "Data tidak ditemukan"
		}
	}

	return errorsMap
}

func IsDuplicateEntryError(err error) bool {
	return err != nil && strings.Contains(err.Error(), "Data duplikat")
}
