<script setup lang="ts">
import { ref, reactive } from "vue";
import { useRouter } from "vue-router";
import Cookies from "js-cookie";
import { useLogin } from "../../composables/useLogin";

interface ValidationErrors {
  [key: string]: string;
}

const router = useRouter();
const { mutate, isPending } = useLogin();

const username = ref<string>("");
const password = ref<string>("");
const errors = reactive<ValidationErrors>({});

const handleLogin = (e: Event) => {
  e.preventDefault();

  Object.keys(errors).forEach((key) => {
    delete errors[key];
  });

  mutate(
    { username: username.value, password: password.value },
    {
      onSuccess: (data: any) => {
        Cookies.set("token", data.data.token);

        Cookies.set(
          "user",
          JSON.stringify({
            id: data.data.id,
            name: data.data.name,
            username: data.data.username,
            email: data.data.email,
          }),
        );
        router.push("/admin/dashboard");
      },
      onError: (error: any) => {
        const validationErrors = error.response?.data?.errors;
        if (validationErrors) {
          Object.entries(validationErrors).forEach(([key, value]) => {
            errors[key.toLowerCase()] = String(value);
          });
        }
      },
    },
  );
};
</script>

<template>
  <div class="p-5 mb-4 bg-light rounded-3 shadow-sm">
    <div class="container-fluid py-5">
      <h1 class="display-5 fw-bold">HALAMAN LOGIN</h1>
      <hr />
      <div v-if="errors.error" class="alert alert-danger mt-2 rounded">
        {{ errors.error }}
      </div>
      <form @submit="handleLogin">
        <div class="form-group mb-3">
          <label class="mb-1 fw-bold">Username</label>
          <input
            v-model="username"
            type="text"
            class="form-control"
            placeholder="Username"
          />
          <div
            v-if="errors.username"
            class="alert alert-danger mt-2 rounded py-1 px-2"
          >
            {{ errors.username }}
          </div>
        </div>
        <div class="form-group mb-3">
          <label class="mb-1 fw-bold">Password</label>
          <input
            v-model="password"
            type="password"
            class="form-control"
            placeholder="Password"
          />
          <div
            v-if="errors.password"
            class="alert alert-danger mt-2 rounded py-1 px-2"
          >
            {{ errors.password }}
          </div>
        </div>
        <button
          type="submit"
          class="btn btn-primary w-100"
          :disabled="isPending"
        >
          {{ isPending ? "Loading" : "Login" }}
        </button>
      </form>
    </div>
  </div>
</template>
