<script setup lang="ts">
import { ref, reactive } from "vue";
import { useRouter } from "vue-router";
import { useRegister } from "../../composables/useRegister";

interface ValidationErrors {
  [key: string]: string;
}

const router = useRouter();

const name = ref<string>("");
const username = ref<string>("");
const email = ref<string>("");
const password = ref<string>("");

const errors = reactive<ValidationErrors>({});

const { mutate, isPending } = useRegister();

const handleRegister = (e: Event) => {
  e.preventDefault();

  Object.keys(errors).forEach((key) => {
    delete errors[key];
  });

  mutate(
    {
      name: name.value,
      username: username.value,
      email: email.value,
      password: password.value,
    },
    {
      onSuccess: () => {
        router.push("/login");
      },
      onError: (error: any) => {
        const validationErrors = error.response?.data?.errors;

        if (validationErrors) {
          Object.entries(validationErrors).forEach(([key, value]) => {
            errors[key.toLowerCase()] = String(value);
          });
        }
      },
    },
  );
};
</script>

<template>
  <div class="p-5 mb-4 bg-light rounded-3 shadow-sm">
    <div class="container-fluid py-5">
      <h1 class="display-5 fw-bold">HALAMAN REGISTER</h1>
      <hr />
      <form @submit.prevent="handleRegister">
        <div class="row">
          <div class="col-md-6 mb-3">
            <div class="form-group">
              <label class="mb-1 fw-bold">Full Name</label>
              <input
                v-model="name"
                type="text"
                class="form-control"
                placeholder="Full Name"
              />
              <div
                v-if="errors.name"
                class="alert alert-danger mt-2 rounded px-2 py-1"
              >
                {{ errors.name }}
              </div>
            </div>
          </div>
          <div class="col-md-6 mb-3">
            <div class="form-group">
              <label class="mb-1 fw-bold">Usename</label>
              <input
                v-model="username"
                type="text"
                class="form-control"
                placeholder="Username"
              />
              <div
                v-if="errors.username"
                class="alert alert-danger mt-2 rounded px-2 py-1"
              >
                {{ errors.username }}
              </div>
            </div>
          </div>
          <div class="col-md-6 mb-3">
            <div class="form-group">
              <label class="mb-1 fw-bold">Email Address</label>
              <input
                v-model="email"
                type="text"
                class="form-control"
                placeholder="Email Address"
              />
              <div
                v-if="errors.email"
                class="alert alert-danger mt-2 rounded px-2 py-1"
              >
                {{ errors.email }}
              </div>
            </div>
          </div>
          <div class="col-md-6 mb-3">
            <div class="form-group">
              <label class="mb-1 fw-bold">Password</label>
              <input
                v-model="password"
                type="text"
                class="form-control"
                placeholder="Password"
              />
              <div
                v-if="errors.password"
                class="alert alert-danger mt-2 rounded px-2 py-1"
              >
                {{ errors.password }}
              </div>
            </div>
          </div>
          <div class="col-md-12 mt-3">
            <button
              type="submit"
              class="btn btn-primary w-100 rounded"
              :disabled="isPending"
            >
              {{ isPending ? "Loading" : "Register" }}
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>
